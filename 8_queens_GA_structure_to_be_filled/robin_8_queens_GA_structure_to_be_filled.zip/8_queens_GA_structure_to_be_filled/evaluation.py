"""
My collection of fitness evaluation methods

"""

#imports


def fitness_8queen (individual): 
    """Compute fitness of an invidual for the 8-queen puzzle (maximization)"""    

    fitness = 0
    # student code begin

    M = 28
    check = 0
    l = len(individual)
    for i in range(0, l):
        for j in range(i + 1, l):
            
            # difference between columnns is not equal to the difference between the rows
                # checks diagonals, straight, rows 


    # student code end
    
    return fitness


