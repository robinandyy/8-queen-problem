"""
My collection of initialization methods for different representations

"""

#imports
import numpy



def permutation (pop_size, genome_length):
    """initialize a population of permutation"""

    population = []
    # student code begin
    for i in range(0, pop_size):
        population.append(numpy.random.permutation(genome_length))
    


    #student code end
    
    return population                     

