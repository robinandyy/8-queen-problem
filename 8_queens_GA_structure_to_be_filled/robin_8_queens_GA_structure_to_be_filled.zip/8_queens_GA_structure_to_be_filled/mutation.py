"""
My colleciton of mutation methods

"""

# imports
import random


def permutation_swap (individual):
    """Mutate a permutation"""

    mutant = individual.copy()
    
    # student code starts
    choice = random.randint(1,8)
    choice2 = random.randint(1,8)

    individual[choice], individual[choice2] = in
   
    # student code ends
    
    return mutant
