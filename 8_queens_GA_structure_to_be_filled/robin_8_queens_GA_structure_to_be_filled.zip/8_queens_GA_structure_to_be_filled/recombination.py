"""
My collection of recombination methods

"""

#imports


def permutation_cut_and_crossfill (parent1, parent2):
    """cut-and-crossfill crossover for permutation representations"""

    offspring1 = []
    offspring2 = []
    
    # student code begin
    
                
    # student code end
    
    return offspring1, offspring2
